package com.example.jarvisvpn;

import android.app.Activity;
import android.os.Bundle;
import android.graphics.Color;
import android.view.View;
import android.widget.*;
import java.util.Arrays;

public class MainActivity extends Activity {
    boolean connected = false;
    TextView status;
    Button connect;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        setContentView(R.layout.activity_main);

        status = findViewById(R.id.status);
        connect = findViewById(R.id.connectButton);
        Spinner spinner = findViewById(R.id.serverSpinner);

        String[] servers = {"Auto / Best", "India", "Singapore", "Germany", "United States"};
        ArrayAdapter<String> adapter = new ArrayAdapter<>(this,
                android.R.layout.simple_spinner_dropdown_item, servers);
        spinner.setAdapter(adapter);

        connect.setOnClickListener(v -> {
            connected = !connected;
            if (connected) {
                status.setText("CONNECTED");
                status.setTextColor(Color.rgb(80, 220, 140));
                connect.setText("DISCONNECT");
            } else {
                status.setText("DISCONNECTED");
                status.setTextColor(Color.rgb(168, 170, 178));
                connect.setText("CONNECT");
            }
        });
    }
}
